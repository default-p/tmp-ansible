# Ansible Collection: raptor.devtools

This repo hosts the `raptor.devtools` Ansible Collection.

The collection includes roles and playbooks supported by the Raptor program to help the management of development tooling applications.

<!--start requires_ansible-->
## Ansible version compatibility

This collection has been tested against following Ansible versions: **>=[2.11](https://confluence.raptor.local/x/ZxEQAw)**.

<!--end requires_ansible-->

## Installation and Usage

### Installing the Collection from Ansible Galaxy

Before using the raptor.devtools collection, you need to install the collection with the `ansible-galaxy` command line tool. Below are some options to install collection on a host:

**TAR ARCHIVE**

    ansible-galaxy collection install http://10.10.1.210:8081/repository/zoom-ansible-collections/raptor-devtools-1.0.0.tar.gz

**SSH GIT REPO**

    ansible-galaxy collection install git+ssh://bitbucket.raptor.local:7999/tools/raptor.devtools.git,main

**REQUIREMENTS FILE**

You can also include it in a `requirements.yml` file and install it via `ansible-galaxy collection install -r requirements.yml` using the format:

```yaml
collections:
- name: ssh://git@bitbucket.raptor.local:7999/tools/raptor.devtools.git
  type: git
  version: main
```

### Required Dependencies


* NONE

## Included content

<!--start collection content-->
### Connection plugins
Name | Description
--- | ---

* NONE

### Inventory plugins
Name | Description
--- | ---

* NONE
  
### Modules
Name | Description
--- | ---

* NONE

### Roles
Name | Description
--- | ---
[raptor.devtools.win_pkgapp](https://bitbucket.raptor.local/projects/TOOLS/repos/raptor.devtools/browse/roles/win_pkgapp/README.md)|Ansible Role to Install and Configure win_pkgapp on Microsoft Windows

### Playbooks
Name | Description
--- | ---
[raptor.devtools.win_pkgapp_setup](https://bitbucket.raptor.local/projects/TOOLS/repos/raptor.devtools/browse/playbooks/win_pkgapp_setup.yml)|Ansible Playbook to Use Role `raptor.win_pkgapp.`

#### Using Collections Content by Fully Qualified Collection Name (FQCN) via Playbook
----------------

```
1. Add variables and values (vars supported by Ansible Role) in external yaml file, such as vars.yml to be used or use --extra-vars (ONLY 1 NEEDS TO BE USED)
   e.g. vars.yml   --extra-vars <key=value>

2. Execute ansible-playbook command with FQCN playbook with desired Ansible options

   e.g. ansible-playbook raptor.devtools.win_pkgapp_setup -b -i </path/to/inventory> -e "@vars.yml"

2a. Specific tag(s) can be used with Ansible playbook to only apply automation grouped by a tag(s) to a specific host (add/update settings)

   e.g. ansible-playbook raptor.devtools.win_pkgapp_setup --tags "uninstall" -b -i </path/to/inventory> -e "@vars.yml"

```

<!--end collection content-->

## Testing and Development

If you want to develop new content for this collection or improve what is already here, the easiest way to work on the collection is to clone it into one of the configured [`COLLECTIONS_PATHS`](https://docs.ansible.com/ansible/latest/reference_appendices/config.html#collections-paths), and work on it there.

- [Guidelines for Ansible Collection development](TODO)

## Communication

Raptor DevOps Team can facilitate support using content.
You can find other people interested in this in the `#ansible-devops` channel on [rocket.chat](https://rocketchat.raptor.local/channel/ansible-devops)

## License

TODO
