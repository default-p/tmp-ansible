raptor.devtools.win_pkgapp
=======================

This role installs and configures MS Windows (.msi) or (.exe) packages

Requirements
------------

* Any pre-installation or post-postinstall is managed through the Ansible win_shell module defaults to Powershell
* Add any win_shell compatible syntax to be invoked during Ansible execution.
* A specific downloadable (.msi) or (.exe) package supporting MS Windows

### Example Adding Variables

```

1. Update Ansible variables with the defined installation package location (e.g. url, file path)
   installation path, and win_shell command to be executed on remote host
  
   win_pkgapp_installation_path: "C:\\Program Files\\<PATH\\TO\\INSTALL\\DIRECTORY\\installpackage.exe>"
   win_pkgapp_download:
     mswinpkg:
       version: 0.0.1
       url: http://path/to/package/source/location/mswinpkg.msi
       checksum_type: sha1
       checksum: <add_checksum>
   win_pkgapp_postinstall_exec_shell_runcmd: curl.exe --url http://localhost:8081/path/to/postinstall
   
```

Role Variables
--------------

| Name                          | Default value |               Description                    |
|-------------------------------|---------------|----------------------------------------------|
| win_pkgapp_is_enabled     | true          | **BOOLEAN**: Enabled (true) to install software components or Disabled (false) to software remove components |
| win_pkgapp_download    | {}            | **DICTIONARY**: Named attributes required to download and install software package component                    |
| win_pkgapp_installation_path    | ""            | **STRING**: Name of path for location target to install sofware package component                      |
| win_pkgapp_preinstall_exec_shell_runcmd    | ""            | **STRING**: Powershell executable code to operate during preinstall with stdout,stderr, and rc results|
| win_pkgapp_postinstall_exec_shell_runcmd    | ""         | **STRING**: Powershell executable code to operate during postinstall with stdout,stderr, and rc results|
| win_pkgapp_uninstall_exec_shell_runcmd    | ""         | **STRING**: Powershell executable code to operate during uninstall with stdout,stderr, and rc results|

Dependencies
------------

None

Example Playbook
----------------

```yaml
---
- hosts: "{{ nodes }}"
  roles:
    - role: raptor.devtools.win_pkgapp
      vars:
        nodes: windowsbox
        win_pkgapp_is_enabled: true
        win_pkgapp_download:
          winzip:
            version: 27.0
            url: http://path/to/package/repository/windows/WinZip/27/winzip270-64.msi
            checksum_type: sha1
            checksum: a123456789987654321123456789098776543212
        win_pkgapp_installation_path: "C:\\Program Files\WinZip\winzip64.exe"

```

How To Use Default Playbook To Install and Configure Windows Software Package
----------------

```
**INSTALL SOFTWARE AND OPERATOR MANUALLY CONFIGURES SOFTWARE**

1. Add role variables (vars) from above in separate file with custom defined values
   e.g. vi vars.yml (INVENTORY CAN BE USED ALTERNATIVELY, BUT NOT RECOMMENDED AS BEST PRACTICE)

2a. Execute ansible-playbook command with FQCN playbook with desired Ansible options

   e.g. ansible-playbook raptor.devtools.win_pkgapp_setup -b -i </path/to/inventory> -e "@vars.yml"

**INSTALL SOFTWARE AND CONFIGURE SOFTWARE VIA ANSIBLE AUTOMATION**

2b. Specific tag(s) can be used with Ansible playbook to only apply postinstall to a specific host (add/update webinspect settings)

   e.g. ansible-playbook raptor.devtools.win_pkgapp_setup --tags "postinstall" -b -i </path/to/inventory> -e "@vars.yml"


```

Document Reference
------------------
- Ansible Module Documentation [Ansible Official Docs](https://docs.ansible.com/ansible/latest/collections/ansible/windows/win_shell_module.html#ansible-collections-ansible-windows-win-shell-module)
- Ansible Module Documentation [Ansible Official Docs](https://docs.ansible.com/ansible/latest/collections/ansible/windows/win_package_module.html)


License
-------

TODO

Author Information
------------------

TODO
