# Ansible Collection: raptor.devkit

This repo hosts the `raptor.devkit` Ansible Collection.

The collection includes roles and playbooks supported by the Raptor program to help the management of development tooling applications.

<!--start requires_ansible-->
## Ansible version compatibility

This collection has been tested against following Ansible versions: **>=[2.11](https://confluence.raptor.local/x/ZxEQAw)**.

<!--end requires_ansible-->

## Installation and Usage

### Installing the Collection from Ansible Galaxy

Before using the raptor.devkit collection, you need to install the collection with the `ansible-galaxy` command line tool. Below are some options to install collection on a host:

**TAR ARCHIVE**

    ansible-galaxy collection install http://10.10.1.210:8081/repository/zoom-ansible-collections/raptor-devkit-1.0.0.tar.gz

**SSH GIT REPO**

    ansible-galaxy collection install git+ssh://bitbucket.raptor.local:7999/tools/raptor.devkit.git,main

**REQUIREMENTS FILE**

You can also include it in a `requirements.yml` file and install it via `ansible-galaxy collection install -r requirements.yml` using the format:

```yaml
collections:
- name: ssh://git@bitbucket.raptor.local:7999/tools/raptor.devkit.git
  type: git
  version: main
```

### Required Dependencies


* NONE

## Included content

<!--start collection content-->
### Connection plugins
Name | Description
--- | ---

* NONE

### Inventory plugins
Name | Description
--- | ---

* NONE
  
### Modules
Name | Description
--- | ---

* NONE

### Roles
Name | Description
--- | ---
[raptor.devkit.lnx_yumcron](https://bitbucket.raptor.local/projects/TOOLS/repos/raptor.devkit/browse/roles/lnx_yumcron/README.md)|Ansible Role to Install and Configure lnx_yumcron on Microsoft Windows

### Playbooks
Name | Description
--- | ---
[raptor.devkit.lnx_yumcron_setup](https://bitbucket.raptor.local/projects/TOOLS/repos/raptor.devkit/browse/playbooks/lnx_yumcron_setup.yml)|Ansible Playbook to Use Role `raptor.lnx_yumcron.`

#### Using Collections Content by Fully Qualified Collection Name (FQCN) via Playbook
----------------

```
1. Add variables and values (vars supported by Ansible Role) in external yaml file, such as vars.yml to be used or use --extra-vars (ONLY 1 NEEDS TO BE USED)
   e.g. vars.yml   --extra-vars <key=value>

2. Execute ansible-playbook command with FQCN playbook with desired Ansible options

   e.g. ansible-playbook raptor.devkit.lnx_yumcron_setup -b -i </path/to/inventory> -e "@vars.yml"

2a. Specific tag(s) can be used with Ansible playbook to only apply automation grouped by a tag(s) to a specific host (add/update settings)

   e.g. ansible-playbook raptor.devkit.lnx_yumcron_setup --tags "uninstall" -b -i </path/to/inventory> -e "@vars.yml"

```

<!--end collection content-->

## Testing and Development

If you want to develop new content for this collection or improve what is already here, the easiest way to work on the collection is to clone it into one of the configured [`COLLECTIONS_PATHS`](https://docs.ansible.com/ansible/latest/reference_appendices/config.html#collections-paths), and work on it there.

- [Guidelines for Ansible Collection development](TODO)

## Communication

Raptor DevOps Team can facilitate support using content.
You can find other people interested in this in the `#ansible-devops` channel on [rocket.chat](https://rocketchat.raptor.local/channel/ansible-devops)

## License

TODO
